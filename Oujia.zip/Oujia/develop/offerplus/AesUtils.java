package offerplus;

/**
 * Created by Luo on 2017/8/29.
 */

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

	/**
	 * 编码工具类
	 * 实现aes加密、解密
	 */
public class AesUtils {
    /**
     * 密钥
     */
    private static final String KEY = "viFZiOhDArcQTjkC";

    /**
     * 算法
     */
    private static final String ALGORITHMSTR = "AES/ECB/PKCS5Padding";

    public static void main(String[] args) throws Exception {

        String str = new String("H4sIAAAAAAAAAAGgA1/8PWu+QvZD8ExRNiDZhz42YuAl54fdLLO18OnsJg4d1qf+FN3RQvOWLsS7CBkjH8Ry7qh4GLGPirH9QHcFYLy3YDu3pZMnvK5S6DA3SeEjUivV9iwpYbDuChFfDowICsCptjSP/Lt/FIu4fIY/OqFZc7rFsI8Fm0zzZc6nIv7u2QEgiIYlXmiX/wgwL/nCNGmiS96rGKBzPp07E7QYyvwTYn4ZtLIAhSESSw+/kv1lMW1TmYSNh0yoqeqc8o6tXlnq0n5oBYlpGZTRhhS6d+KfkQK0knC2xEBhfb1pJBKTQ0zEl85hDqPqeUEnidT5xi42bsdc+0AghGhmJCvk+5QZfgie/fmuBAFfMHq6zlCs6fid16jlKw5I/uAs8q25ob6ui+t7+0iM4CDhqIVyL4QTnAOnmc50RL0j6sTc5ek1HRUh9V/YDEnqI3Il/mOMNggOKPHWxUEURer5QuEF3kpDj3PBZcazgclazr+B7+hL3eItgSdBo7OREsBJBtKWrlFENs0hROonUx5eeeKb84ZmTlybtyeOk9qqNTyQnsIn8F6Dccp1NN5YRpmefdLeDFR7KagAUfsWUq1TI+zwLzoV9i/U4CkgNQtWxfcv8y/Cs9i+j+3F1msk5xNbwN++oM9bt9yYmr/Qzjlehzd32SSXCTidgIwhRz959v0dx3UjtO//aKCYd2wswjUON3qTk+nojBZiHiHH9U1aviHX3HiBy+dFUAhHyzeFfyma9poRNONsttbS+wPmw7eW2y4tRIb19ekMepvZTKbMLHNiuUzDXRBiqN67AEPPVnVR8jHbBoVH7l+o50PqtEXzYEJO1VtGNRkaEAUJB9gcqCFC3sjDRPFdXvY35sltVGRirbK0Ms66bUFDVfexmII+aPgfDJn3WauA7eBJSCDDvFIAZWzE+DRjAZIBo2OeQj1i2vMxaqQK/GFLt3UmyfGJk3vjri0q5o2SbUSn7wUGcj1oliZ1PD6bq51vllBj+b48MeB3cMUcl8NgTnFuk35JhiJEMBq+ebyCrUat7Pns6ZjBOOgx3ebrIq0Z0atCxh/LcZChIghfXIveC4aRq/6xNe1mZgZr9JWT3Noz39ECLre76VS7JYsplC1gSZhOhr30GvkzdhzxHsiPKOanLGHmPCkhqfIKftkBryILTx7s6t1wMEJpQbkj/J7rwS4gr+Cs0O0mSCrLGkrSgrLSmhS2wTZNgG6AwvnopHCN5qhF8eVbgemsIFChOb2gAwAA");
        System.out.println(str);
        String un = aesDecryptByBytes(uncompress(base64Decode(str)), "6mpQfK5BSzzOfrZ6");
        System.out.println("解密后：" + un);
    }

    /**
     * aes解密
     *
     * @param encrypt 内容
     * @return
     * @throws Exception
     */
    public static String aesDecrypt(String encrypt) throws Exception {
        return aesDecrypt(encrypt, KEY);
    }

    /**
     * aes加密
     *
     * @param content
     * @return
     * @throws Exception
     */
    public static String aesEncrypt(String content) throws Exception {
        return aesEncrypt(content, KEY);
    }

    /**
     * 将byte[]转为各种进制的字符串
     *
     * @param bytes byte[]
     * @param radix 可以转换进制的范围，从Character.MIN_RADIX到Character.MAX_RADIX，超出范围后变为10进制
     * @return 转换后的字符串
     */
    public static String binary(byte[] bytes, int radix) {
        return new BigInteger(1, bytes).toString(radix);// 这里的1代表正数
    }

    /**
     * base 64 encode
     *
     * @param bytes 待编码的byte[]
     * @return 编码后的base 64 code
     */
    public static String base64Encode(byte[] bytes) {
        return Base64.encodeBase64String(bytes);
    }

    /**
     * base 64 decode
     *
     * @param base64Code 待解码的base 64 code
     * @return 解码后的byte[]
     * @throws Exception
     */
    public static byte[] base64Decode(String base64Code) throws Exception {
        return StringUtils.isEmpty(base64Code) ? null : Base64.decodeBase64(base64Code);
    }


    /**
     * AES加密
     *
     * @param content    待加密的内容
     * @param encryptKey 加密密钥
     * @return 加密后的byte[]
     * @throws Exception
     */
    public static byte[] aesEncryptToBytes(String content, String encryptKey) throws Exception {
        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        kgen.init(128);
        Cipher cipher = Cipher.getInstance(ALGORITHMSTR);
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(encryptKey.getBytes(), "AES"));
        return cipher.doFinal(content.getBytes("utf-8"));
    }

    /**
     * AES加密为base 64 code
     *
     * @param content    待加密的内容
     * @param encryptKey 加密密钥
     * @return 加密后的base 64 code
     * @throws Exception
     */
    public static String aesWebEncrypt(String content, String encryptKey) throws Exception {
        return base64Encode(aesEncryptToBytes(content, encryptKey));
    }

    /**
     * AES加密为base 64 code
     *
     * @param content    待加密的内容
     * @param encryptKey 加密密钥
     * @return 加密后的base 64 code
     * @throws Exception
     */
    public static String aesEncrypt(String content, String encryptKey) throws Exception {
        return base64Encode(compress(aesEncryptToBytes(content, encryptKey)));
    }

    /**
     * AES解密
     *
     * @param encryptBytes 待解密的byte[]
     * @param decryptKey   解密密钥
     * @return 解密后的String
     * @throws Exception
     */
    public static String aesDecryptByBytes(byte[] encryptBytes, String decryptKey) throws Exception {
        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        kgen.init(128);
        Cipher cipher = Cipher.getInstance(ALGORITHMSTR);
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(decryptKey.getBytes(), "AES"));
        byte[] decryptBytes = cipher.doFinal(encryptBytes);
        return new String(decryptBytes);
    }

    /**
     * 将base 64 code AES解密
     *
     * @param encryptStr 待解密的base 64 code
     * @param decryptKey 解密密钥
     * @return 解密后的string
     * @throws Exception
     */
    public static String aesDecrypt(String encryptStr, String decryptKey) throws Exception {
        return StringUtils.isEmpty(encryptStr) ? null : aesDecryptByBytes(base64Decode(encryptStr), decryptKey);
    }

    /**
     * 压缩
     *
     * @param bytes
     * @return
     */
    public static byte[] compress(byte[] bytes) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        GZIPOutputStream gzip;
        try {
            gzip = new GZIPOutputStream(out);
            gzip.write(bytes);
            gzip.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return out.toByteArray();
    }

    /**
     * 解压
     *
     * @param bytes
     * @return
     */
    public static byte[] uncompress(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayInputStream in = new ByteArrayInputStream(bytes);
        try {
            GZIPInputStream ungzip = new GZIPInputStream(in);
            byte[] buffer = new byte[256];
            int n;
            while ((n = ungzip.read(buffer)) >= 0) {
                out.write(buffer, 0, n);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return out.toByteArray();
    }
}
