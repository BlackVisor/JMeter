package offerplus;

import java.util.ArrayList;


public class Combine {
    public static void main(String[]args)throws Exception {
        int min = 1003001;
        int max = 1003030;
        ArrayList<Integer> users = new ArrayList<Integer>();
        for(int i=0; i<(max-min+1); i++){
            users.add(min+i);
        }
        int num = (max-min)*(max-min+1)/2;
//      用类似手机信号的模型去模拟，每一轮共max-min个，然后将头部的那个去掉，剩下的再开始一轮，这样就不会重复了
        ArrayList<ArrayList<ArrayList<Integer>>>  list = new ArrayList<ArrayList<ArrayList<Integer>>>();
        for(int j=0; j<(max-min+1); j++){
            ArrayList<ArrayList<Integer>> listSub = new ArrayList<ArrayList<Integer>>();
            for(int k=j+1; k<(max-min+1); k++){
                ArrayList<Integer> listSubSub = new ArrayList<Integer>();
                listSubSub.add(users.get(j));
                listSubSub.add(users.get(k));
                listSub.add(listSubSub);
            }
            list.add(listSub);//二维数组放到集合中
        }
        ArrayList combination = new ArrayList();
        for(int l=0; l<list.size(); l++){
            for(int m=0; m<list.get(l).size(); m++){
                combination.add(list.get(l).get(m));
            }
        }
        System.out.println(combination);
    }
}