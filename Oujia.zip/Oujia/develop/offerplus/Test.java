package offerplus;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.codec.digest.DigestUtils;

import java.text.DecimalFormat;
import java.util.*;


public class Test {
    public static void main(String[]args)throws Exception {

    }
}