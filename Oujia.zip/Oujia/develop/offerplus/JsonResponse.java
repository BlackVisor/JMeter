package offerplus;

import com.alibaba.fastjson.JSONObject;

import java.util.*;

public class JsonResponse {
    public static void main(String[]args)throws Exception {
        System.out.print("input=");
        Scanner scanner = new Scanner(System.in);
        String encrypt = scanner.nextLine();
        JSONObject response = JSONObject.parseObject(encrypt);
        if(response.containsKey("data")){
            JSONObject duplicate = response.getJSONObject("data");
            JSONObject dup = new JSONObject();

            dup.put("contactName", duplicate.getString("contactName"));
            dup.put("contactUserId", duplicate.getInteger("contactUserId"));
            if(duplicate.containsKey("offerArrSheet")){
                dup.put("offerArrSheet", duplicate.getJSONArray("offerArrSheet"));
            }
            if(duplicate.containsKey("offerBuyPrice")){
                dup.put("offerBuyPrice", duplicate.getString("offerBuyPrice"));
                dup.put("offerBuyCry", duplicate.getString("offerBuyCry"));
            }
            if(duplicate.containsKey("offerSellPrice")){
                dup.put("offerSellPrice", duplicate.getString("offerSellPrice"));
                dup.put("offerSellCry", duplicate.getString("offerSellCry"));
            }
            if(duplicate.containsKey("offerDescrip")){
                dup.put("offerDescrip", duplicate.getString("offerDescrip"));
            }
            dup.put("offerImg", duplicate.getString("contactName"));
            dup.put("offerName", duplicate.getString("contactName"));
            if(duplicate.containsKey("offerUnit")){
                dup.put("offerUnit", duplicate.getString("offerUnit"));
            }
            if(duplicate.containsKey("offerArrSheet")){
                if(duplicate.getJSONArray("offerArrSheet").size()==0){
                    duplicate.remove("offerArrSheet");
                }
            }
            System.out.println(dup.toJSONString());
        }

    }

}