package offerplus;
/**
 * 
 */

/** 
 * @author 作者 E-mail: 
 * @version 创建时间：2017年10月27日 上午9:29:38 
 * 类说明 
 */

import java.util.Scanner;
import java.util.zip.ZipException;

/**
 * @author huhuichao
 *
 */
public class AesTest {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {

        String webKey = "viFZiOhDArcQTjkC";
        String appKey = "6mpQfK5BSzzOfrZ6";
        AesUtils aes = new AesUtils();
        System.out.print("待解密的字符串=");
        Scanner scanner = new Scanner(System.in);
        String encrypted = scanner.nextLine();

        try {
            String encrypt = encrypted;
            byte[] un = aes.uncompress(aes.base64Decode(encrypt));
            String jsonStr = new String(aes.aesDecryptByBytes(un, appKey).getBytes(), "UTF-8");
            System.out.println("app解密后：" + jsonStr);
        } catch (ZipException e) {
            System.out.println("不适用App解密");
        }

        try {
            //web端入参的加密解密操作
            String webEncrypt = encrypted;
            System.out.println("web入参解密后：" + aes.aesDecrypt(webEncrypt, webKey));
        }
        catch (Exception e) {
            System.out.println("不适用Web入参解密");
        }

        try {
            //web端出参的加密解密操作
            String webEncrypt2 = encrypted;
            String webUn = aes.aesDecryptByBytes(aes.base64Decode(webEncrypt2), webKey);
            System.out.println("web出参解密后：" + java.net.URLDecoder.decode(new String(aes.uncompress(aes.base64Decode(webUn))), "utf-8"));

        }
        catch (Exception e) {
            System.out.println("不适用Web出参解密");
        }
    }
}
